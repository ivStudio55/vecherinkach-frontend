module.exports=[32402,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_packs_room_%5BroomId%5D_route_actions_102005a2.js.map