module.exports=[30069,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_survivach_create_route_actions_93fb1012.js.map