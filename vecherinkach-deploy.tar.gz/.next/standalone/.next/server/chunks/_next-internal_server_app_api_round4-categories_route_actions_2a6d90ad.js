module.exports=[56689,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_round4-categories_route_actions_2a6d90ad.js.map