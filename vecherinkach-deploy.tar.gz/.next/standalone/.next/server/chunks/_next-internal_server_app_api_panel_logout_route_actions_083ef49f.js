module.exports=[53839,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_logout_route_actions_083ef49f.js.map