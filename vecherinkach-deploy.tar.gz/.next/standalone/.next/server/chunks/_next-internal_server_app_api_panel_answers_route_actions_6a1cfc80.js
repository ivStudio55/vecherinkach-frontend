module.exports=[45767,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_answers_route_actions_6a1cfc80.js.map