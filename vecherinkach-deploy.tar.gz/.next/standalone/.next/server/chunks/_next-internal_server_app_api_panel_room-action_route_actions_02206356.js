module.exports=[50922,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_room-action_route_actions_02206356.js.map