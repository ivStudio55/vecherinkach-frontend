module.exports=[51924,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_jingle_audio_route_actions_13dba5d7.js.map