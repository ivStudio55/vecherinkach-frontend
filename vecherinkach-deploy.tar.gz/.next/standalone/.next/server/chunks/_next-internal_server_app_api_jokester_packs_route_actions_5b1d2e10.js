module.exports=[95267,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_jokester_packs_route_actions_5b1d2e10.js.map