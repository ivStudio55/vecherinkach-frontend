module.exports=[99203,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_room-detail_route_actions_2b36ad91.js.map