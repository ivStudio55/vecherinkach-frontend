module.exports=[21386,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_packs_route_actions_25dde4ae.js.map