module.exports=[79039,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_prices_route_actions_37715e2e.js.map