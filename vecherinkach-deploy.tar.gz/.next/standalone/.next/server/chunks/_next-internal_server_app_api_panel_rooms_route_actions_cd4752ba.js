module.exports=[61199,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_rooms_route_actions_cd4752ba.js.map