module.exports=[63685,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_packs_route_actions_8060b737.js.map