module.exports=[42455,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pricing-packs_route_actions_df2a902b.js.map