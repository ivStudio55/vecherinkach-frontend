module.exports=[3277,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_stats_route_actions_055aa297.js.map