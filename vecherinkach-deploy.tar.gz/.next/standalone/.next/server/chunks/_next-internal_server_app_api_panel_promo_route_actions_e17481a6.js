module.exports=[91937,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_promo_route_actions_e17481a6.js.map