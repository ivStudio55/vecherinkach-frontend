module.exports=[30254,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_jokester-packs_route_actions_79f733f7.js.map