module.exports=[40099,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_round3_questions_route_actions_c0fc4611.js.map