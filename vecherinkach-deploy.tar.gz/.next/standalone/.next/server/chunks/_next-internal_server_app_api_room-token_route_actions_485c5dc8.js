module.exports=[16276,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_room-token_route_actions_485c5dc8.js.map