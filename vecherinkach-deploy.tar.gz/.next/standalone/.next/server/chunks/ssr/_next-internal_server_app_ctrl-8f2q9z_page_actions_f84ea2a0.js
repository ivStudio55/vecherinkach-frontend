module.exports=[3155,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_page_actions_f84ea2a0.js.map