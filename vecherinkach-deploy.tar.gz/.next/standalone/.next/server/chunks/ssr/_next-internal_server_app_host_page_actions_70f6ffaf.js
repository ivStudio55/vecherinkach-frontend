module.exports=[99764,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_host_page_actions_70f6ffaf.js.map