module.exports=[69386,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_jokester_spectator_%5Bcode%5D_page_actions_e0e522a8.js.map