module.exports=[38810,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_creativach_room_%5Bcode%5D_page_actions_63d0cad2.js.map