module.exports=[9613,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_answers_page_actions_c9f11faf.js.map