module.exports=[61297,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_jokester_page_actions_f73d996d.js.map