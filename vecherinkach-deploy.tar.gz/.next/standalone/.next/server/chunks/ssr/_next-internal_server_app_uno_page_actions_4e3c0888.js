module.exports=[73593,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_uno_page_actions_4e3c0888.js.map