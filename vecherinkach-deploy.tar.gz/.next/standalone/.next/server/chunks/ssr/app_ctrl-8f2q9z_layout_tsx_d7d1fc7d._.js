module.exports=[74220,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_ctrl-8f2q9z_layout_tsx_d7d1fc7d._.js.map