module.exports=[93035,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_prices_page_actions_5d372765.js.map