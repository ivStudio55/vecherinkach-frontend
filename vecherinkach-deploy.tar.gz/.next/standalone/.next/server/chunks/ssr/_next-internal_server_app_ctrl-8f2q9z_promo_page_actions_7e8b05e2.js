module.exports=[98376,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_promo_page_actions_7e8b05e2.js.map