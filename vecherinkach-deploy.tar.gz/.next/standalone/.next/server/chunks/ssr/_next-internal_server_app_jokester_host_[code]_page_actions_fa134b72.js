module.exports=[82244,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_jokester_host_%5Bcode%5D_page_actions_fa134b72.js.map