module.exports=[20816,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_jokester-packs_page_actions_0ad3dd71.js.map