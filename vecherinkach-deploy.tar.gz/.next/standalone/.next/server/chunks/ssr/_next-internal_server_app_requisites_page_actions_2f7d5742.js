module.exports=[34648,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_requisites_page_actions_2f7d5742.js.map