module.exports=[26204,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_host_%5BroomId%5D_page_actions_06c663f8.js.map