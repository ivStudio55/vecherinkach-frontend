module.exports=[71224,a=>{a.v("/_next/static/media/icon.16decb6f.png")},1022,a=>{"use strict";let b={src:a.i(71224).default,width:450,height:450};a.s(["default",0,b])}];

//# sourceMappingURL=app_e744e06a._.js.map