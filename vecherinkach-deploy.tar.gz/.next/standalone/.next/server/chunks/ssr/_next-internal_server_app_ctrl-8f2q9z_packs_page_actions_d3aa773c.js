module.exports=[55242,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_packs_page_actions_d3aa773c.js.map