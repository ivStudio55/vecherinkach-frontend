module.exports=[83937,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_creativach_spectator_%5Bcode%5D_page_actions_78f698dc.js.map