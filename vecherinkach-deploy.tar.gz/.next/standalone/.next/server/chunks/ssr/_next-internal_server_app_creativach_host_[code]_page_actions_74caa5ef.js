module.exports=[35550,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_creativach_host_%5Bcode%5D_page_actions_74caa5ef.js.map