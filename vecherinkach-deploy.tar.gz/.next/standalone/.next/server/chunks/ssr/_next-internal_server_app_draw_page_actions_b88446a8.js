module.exports=[85435,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_draw_page_actions_b88446a8.js.map