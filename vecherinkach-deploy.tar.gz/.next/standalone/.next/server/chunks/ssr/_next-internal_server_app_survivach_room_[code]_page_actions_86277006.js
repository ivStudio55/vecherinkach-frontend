module.exports=[26267,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_survivach_room_%5Bcode%5D_page_actions_86277006.js.map