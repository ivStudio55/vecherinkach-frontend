module.exports=[88531,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_jokester_room_%5Bcode%5D_page_actions_7db99edd.js.map