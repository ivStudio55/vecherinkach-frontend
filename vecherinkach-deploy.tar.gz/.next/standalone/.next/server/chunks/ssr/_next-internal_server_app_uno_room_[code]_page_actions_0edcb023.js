module.exports=[4025,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_uno_room_%5Bcode%5D_page_actions_0edcb023.js.map