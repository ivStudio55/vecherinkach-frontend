module.exports=[32362,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_creativach_page_actions_ba16e057.js.map