module.exports=[38604,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_survivach_page_actions_b4c7b85e.js.map