module.exports=[35818,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_offer_page_actions_9d6ba476.js.map