module.exports=[81813,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_host_%5BroomId%5D_qr_page_actions_57d78302.js.map