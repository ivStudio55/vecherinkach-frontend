module.exports=[1299,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_login_page_actions_46135559.js.map