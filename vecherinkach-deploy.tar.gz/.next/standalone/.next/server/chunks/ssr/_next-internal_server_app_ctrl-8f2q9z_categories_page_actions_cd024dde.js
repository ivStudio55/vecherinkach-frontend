module.exports=[25971,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ctrl-8f2q9z_categories_page_actions_cd024dde.js.map