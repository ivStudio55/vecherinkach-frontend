module.exports=[53524,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_panel_round4-categories_route_actions_1d5da7a8.js.map