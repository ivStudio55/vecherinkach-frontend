1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[50782,["/_next/static/chunks/fe4637a1f104c8be.js","/_next/static/chunks/1e98153c15766519.js","/_next/static/chunks/f59830b3fa194ee8.js"],"default"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"OutletBoundary"]
0:{"buildId":"p_9AQujQwl7vRBN9HiJLB","rsc":["$","$1","c",{"children":[["$","$2",null,{"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/f59830b3fa194ee8.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
