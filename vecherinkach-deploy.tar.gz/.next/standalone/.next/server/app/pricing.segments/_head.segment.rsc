1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"ViewportBoundary"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
7:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"IconMark"]
0:{"buildId":"p_9AQujQwl7vRBN9HiJLB","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","title","0",{"children":"Пакеты — Вечеринкач"}],["$","meta","1",{"name":"description","content":"Бесплатные и платные пакеты вопросов для Вечеринкача и Пошутикача"}],["$","meta","2",{"name":"Cache-Control","content":"no-store, no-cache, must-revalidate, max-age=0"}],["$","meta","3",{"name":"Pragma","content":"no-cache"}],["$","meta","4",{"name":"Expires","content":"0"}],["$","meta","5",{"name":"p:domain_verify","content":"696b79383a55fdd264184edf3a03766d"}],["$","link","6",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","link","7",{"rel":"icon","href":"/favicon.ico"}],["$","$L7","8",{}]]
