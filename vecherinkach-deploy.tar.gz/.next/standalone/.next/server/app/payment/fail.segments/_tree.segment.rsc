:HL["/_next/static/chunks/2473c16c0c2f6b5f.css","style"]
:HL["/_next/static/chunks/d87447877f5994f6.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.dbea232f.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.853070df.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"buildId":"p_9AQujQwl7vRBN9HiJLB","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"payment","paramType":null,"paramKey":"payment","hasRuntimePrefetch":false,"slots":{"children":{"name":"fail","paramType":null,"paramKey":"fail","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
